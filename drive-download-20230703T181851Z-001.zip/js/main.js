document.getElementById("header").innerHTML=` <nav class="navbar navbar-expand-sm
navbar-light bg-light">
<div class="container">
<a class="navbar-brand" href="../templates/productos.html">CRUD</a>

</div>
</nav>`